# -*- coding: utf-8 -*-
import os
import sys
import xbmcplugin
import xbmcaddon
import xbmcgui

__scriptname__ = 'WEEB.TV'
__scriptID__ = 'plugin.video.weeb.tv'
__author__ = 'weeb.tv'
__url__ = 'http://weeb.tv'
__credits__ = 'pliszko, mikane(edit)'
__addon__ = xbmcaddon.Addon(__scriptID__)
__language__ = __addon__.getLocalizedString
t = __language__

sys.path.append(os.path.join(os.path.join( __addon__.getAddonInfo('path'), 'resources' ), 'lib'))

import main

MENU = {
    1: [ t(56001).encode('utf-8'), '1.png', 1, False, False ],
    2: [ t(56002).encode('utf-8'), '2.png', 2, False, False ],
    3: [ t(56003).encode('utf-8'), '3.png', 3, False, False ],
    4: [ t(56004).encode('utf-8'), '4.png', 4, False, False ],
    5: [ t(56005).encode('utf-8'), '5.png', 5, False, False ],
    6: [ t(56006).encode('utf-8'), 'favorites.png', 6, False, False ],
    7: [ t(56007).encode('utf-8'), '7.png', 7, False, False ],
    8: [ t(56100).encode('utf-8'), 'settings.png', 200, False, False ]
}

class Start:
    def __init__(self):
        self.showListOptions()
    
    def addDir(self, name, mode, icon, autoplay, isPlayable = True):
        u = '%s?mode=%d' % (sys.argv[0], mode)
        icon = os.path.join( __addon__.getAddonInfo('path'), 'images/' ) + icon
        if autoplay or icon == '':
            icon = 'DefaultVideo.png'
        li = xbmcgui.ListItem(name, iconImage = icon, thumbnailImage = icon)
        if autoplay and isPlayable:
            li.setProperty('IsPlayable', 'true')
        li.setInfo( type = 'Video', infoLabels = { 'Title': name } )
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = li, isFolder = not autoplay)
    
    def showListOptions(self):
        handler = main.Handler()
        parser = main.UrlParser()
        params = parser.getParams()
        mode = parser.getIntParam(params, 'mode')
        s = main.Settings()
        if mode == None or mode == '':
            s.setViewMode('4')
            for n, v in MENU.items():
                self.addDir(v[0], v[2], v[1], v[3], v[4])
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
        elif mode == 1:
            handler.run(1)
            s.setViewMode(__addon__.getSetting('channel_list_view'))
        elif mode == 2:
            handler.run(2)
            s.setViewMode(__addon__.getSetting('channel_list_view'))
        elif mode == 3:
            handler.run(3)
            s.setViewMode(__addon__.getSetting('channel_list_view'))
        elif mode == 4:
            handler.run(4)
            s.setViewMode(__addon__.getSetting('channel_list_view'))
        elif mode == 5:
            handler.run(5)
            s.setViewMode(__addon__.getSetting('channel_list_view'))
        elif mode == 6:
            s.setViewMode('4')
            msg = main.Messages()
            msg.Warning(t(57023).encode('utf-8'), t(57024).encode('utf-8'))
        elif mode == 7:
            s.setViewMode('4')
            ip = main.Settings()
            ip = ip.checkVersion()
            msg = main.Messages()
            if ip['status'] == 2:
                msg.Warning(t(57023).encode('utf-8'), t(57049).encode('utf-8'))
            elif ip['status'] == 3:
                msg.Warning(t(57023).encode('utf-8'), t(57050).encode('utf-8'), t(57048).encode('utf-8'))
            elif ip['status'] == 4:
                msg.Warning(t(57023).encode('utf-8'), t(57051).encode('utf-8'), t(57048).encode('utf-8'))
            elif ip['status'] == 5:
                msg.Warning(t(57023).encode('utf-8'), t(57052).encode('utf-8'), t(57048).encode('utf-8'))
            else:
                msg.Warning(t(57023).encode('utf-8'), t(57053).encode('utf-8'), t(57054).encode('utf-8'))
        elif mode == 200:
            s.setViewMode('4')
            s.showSettings()

init = Start()
